/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([68],{409:function(e,t,r){"use strict";function n(e,t){var r={};for(var n in e)t.indexOf(n)>=0||Object.prototype.hasOwnProperty.call(e,n)&&(r[n]=e[n]);return r}Object.defineProperty(t,"__esModule",{value:!0});var a=r(0),u=(function(e){return e&&e.__esModule?e:{default:e}})(a);t.default=function(e){var t=e.children,r=(e.customHandler,e.data,e.type,n(e,["children","customHandler","data","type"]));return u.default.createElement("div",r,t)},e.exports=t.default}});