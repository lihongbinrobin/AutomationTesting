/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
!(function(e){function r(n){if(n.ysp)return e.ysp||(e.ysp=n.ysp),n.ysp;var o=n.frameElement;if(!o)return null;var a=o._ysp;return a?(e.ysp||(e.ysp=a),a):n.parent!==n?r(n.parent):null}if(window.__ysp_baseReferrerUrl__){var n=window.__ysp_baseReferrerUrl__,o=window.location.href||"",a="",i=document.createElement("a");i.href=n,a=i.origin,i.href=o;var t=i.origin,s=i.pathname||"",p=i.search||"",l=i.Hash||"";if(a&&t&&t!==a&&(console.warn("当前页面跨域了，开始执行跨域逻辑替换"),console.warn("from - "+t),console.warn("to - "+a),!t.match("_ysp_realurl=")))return window.stop(),void(window.location.href=[a,"/?_ysp_realurl="+encodeURIComponent(String(t+s+p+l)),"&_ysp_baseTaghref="+encodeURIComponent(String(t+s)),p?"&"+p.replace(/^\?/,""):"",l||""].join(""))}var _=r(e);_&&e.frameElement&&_.runtime&&_.runtime.Browser.override(e)})(window);