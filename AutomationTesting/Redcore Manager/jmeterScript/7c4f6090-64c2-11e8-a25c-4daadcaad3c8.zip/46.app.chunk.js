/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([46],{390:function(e,a,t){"use strict";Object.defineProperty(a,"__esModule",{value:!0});var l=t(0),u=(function(e){return e&&e.__esModule?e:{default:e}})(l);t(643),a.default=function(e){return u.default.createElement("ul",{"data-am-widget":"gallery",className:"am-gallery am-avg-sm-2 am-avg-md-3 am-avg-lg-4 am-no-layout am-gallery-"+e.type},e.children)},e.exports=a.default},643:function(e,a){}});