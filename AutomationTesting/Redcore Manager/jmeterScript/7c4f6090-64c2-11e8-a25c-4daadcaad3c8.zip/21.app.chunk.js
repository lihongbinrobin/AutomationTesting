/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([21],{431:function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{default:e}}function a(e,t){var n={};for(var r in e)t.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(n[r]=e[r]);return n}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},c=n(0),l=r(c),u=n(12),f=r(u),s=n(938),i=r(s);t.default=function(e){var t=e.className,n=e.children,r=a(e,["className","children"]);return l.default.createElement("div",o({},r,{className:(0,f.default)(t,i.default.content)}),n)},e.exports=t.default},938:function(e,t){e.exports={content:"_1FU-k-6xF-xWxfvbBDAEqg"}}});