/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([23],{429:function(e,t,r){"use strict";function a(e){return e&&e.__esModule?e:{default:e}}function n(e,t){var r={};for(var a in e)t.indexOf(a)>=0||Object.prototype.hasOwnProperty.call(e,a)&&(r[a]=e[a]);return r}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},u=r(0),c=a(u),f=r(12),l=a(f),s=r(936),i=a(s),d=function(e){var t,r=e.className,a=n(e,["className"]);return c.default.createElement("div",o({},a,{className:(0,l.default)(r,(t={},t[i.default.hide]=!0,t))}),"我是 section 组件")};t.default=d,e.exports=t.default},936:function(e,t){e.exports={hide:"_3vD_w6q2a7iNgkGgyOftdn"}}});