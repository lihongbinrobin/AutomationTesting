/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([73],{400:function(e,t,a){"use strict";function r(e){return e&&e.__esModule?e:{default:e}}function n(e,t){var a={};for(var r in e)t.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(a[r]=e[r]);return a}Object.defineProperty(t,"__esModule",{value:!0});var l=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var a=arguments[t];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(e[r]=a[r])}return e},c=a(0),s=r(c),o=a(12),u=r(o),f=function(e){var t=e.className,a=n(e,["className"]);return s.default.createElement("header",l({},a,{className:(0,u.default)("navbar",a.class,t)}),s.default.createElement("h2",{className:"navbar-title navbar-center"},a.title),a.children)};t.default=f,e.exports=t.default}});