/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([75],{397:function(e,r,t){"use strict";function n(e){return e&&e.__esModule?e:{default:e}}function a(e,r){var t={};for(var n in e)r.indexOf(n)>=0||Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t}Object.defineProperty(r,"__esModule",{value:!0});var c=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e},o=t(0),l=n(o),u=t(12),s=n(u),f=t(77);r.default=function(e){var r=e.className,t=e.children,n=a(e,["className","children"]);return l.default.createElement(f.Accordion,c({},n,{className:(0,s.default)(r)}),t)},e.exports=r.default}});