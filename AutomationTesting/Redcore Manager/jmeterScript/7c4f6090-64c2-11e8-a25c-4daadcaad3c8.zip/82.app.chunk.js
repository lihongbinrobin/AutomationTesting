/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([82],{391:function(e,t,l){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var a=l(0),r=(function(e){return e&&e.__esModule?e:{default:e}})(a);t.default=function(e){var t=e.onClick,l=e.link,a=e.url,c=e.descript,n=e.date;return r.default.createElement("li",null,r.default.createElement("div",{className:"am-gallery-item"},r.default.createElement("a",{onClick:t,href:l},r.default.createElement("img",{src:a,alt:c}),r.default.createElement("h3",{className:"am-gallery-title"},c),r.default.createElement("div",{className:"am-gallery-desc"},n))))},e.exports=t.default}});