/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([26],{426:function(e,t,r){"use strict";function a(e){return e&&e.__esModule?e:{default:e}}function n(e,t){var r={};for(var a in e)t.indexOf(a)>=0||Object.prototype.hasOwnProperty.call(e,a)&&(r[a]=e[a]);return r}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},u=r(0),l=a(u),c=r(12),f=a(c),s=r(933),i=a(s),d=function(e){var t,r=e.className,a=n(e,["className"]);return l.default.createElement("div",o({},a,{className:(0,f.default)(r,(t={},t[i.default.hide]=!1,t))}),"我是modal组件")};t.default=d,e.exports=t.default},933:function(e,t){}});