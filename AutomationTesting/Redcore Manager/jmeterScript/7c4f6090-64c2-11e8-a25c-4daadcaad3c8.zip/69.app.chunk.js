/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([69],{405:function(e,t,a){"use strict";function r(e){return e&&e.__esModule?e:{default:e}}function c(e,t){var a={};for(var r in e)t.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(a[r]=e[r]);return a}Object.defineProperty(t,"__esModule",{value:!0});var l=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var a=arguments[t];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(e[r]=a[r])}return e},n=a(0),d=r(n),o=a(12),s=r(o),u=a(77),f=function(e){var t=e.className,a=e.checked,r=e.disabled,n=e.text,o=c(e,["className","checked","disabled","text"]);return d.default.createElement(u.List.Item,l({nested:"checkbox"},o,{className:(0,s.default)(t),style:{border:"1px solid #ccc",background:r?"#f2f2f2":""}}),d.default.createElement(u.Field,{type:"checkbox",checked:a,disabled:r,label:n}))};t.default=f,e.exports=t.default}});