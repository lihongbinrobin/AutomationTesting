/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([76],{396:function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e};t.default=function(e){return o.default.createElement("div",n({"data-ysp":"component",draggable:"true"},e))};var a=r(0),o=(function(e){return e&&e.__esModule?e:{default:e}})(a);e.exports=t.default}});