/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([67],{410:function(e,t,r){"use strict";function a(e,t){var r={};for(var a in e)t.indexOf(a)>=0||Object.prototype.hasOwnProperty.call(e,a)&&(r[a]=e[a]);return r}Object.defineProperty(t,"__esModule",{value:!0});var n=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},i=r(0),o=(function(e){return e&&e.__esModule?e:{default:e}})(i),d=r(79);t.default=function(e){var t=e.dateTime,r=e.date,i=e.format,l=e.interiorCustomHandler,u=e.isReadOnly,s=e.disabled,f=a(e,["dateTime","date","format","interiorCustomHandler","isReadOnly","disabled"]);return o.default.createElement(d.DateTimeInput,n({},f,{disabled:s||u,dateTime:t||r||(u||s?" ":"请选择"),format:i||"YYYY-MM-DD",showTimePicker:!!i&&-1!==i.indexOf(" "),interiorCustomHandler:l}))},e.exports=t.default}});