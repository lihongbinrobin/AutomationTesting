/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([71],{402:function(e,t,r){"use strict";function a(e){return e&&e.__esModule?e:{default:e}}function n(e,t){var r={};for(var a in e)t.indexOf(a)>=0||Object.prototype.hasOwnProperty.call(e,a)&&(r[a]=e[a]);return r}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},c=r(0),u=a(c),l=r(12),s=a(l);t.default=function(e){var t=e.className,r=n(e,["className"]);return u.default.createElement("div",o({},r,{className:(0,s.default)(t,"card-body")}))},e.exports=t.default}});