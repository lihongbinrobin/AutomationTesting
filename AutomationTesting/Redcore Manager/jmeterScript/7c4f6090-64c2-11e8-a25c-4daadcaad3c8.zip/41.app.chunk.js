/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([41],{375:function(e,t,n){"use strict";function a(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var a in n)Object.prototype.hasOwnProperty.call(n,a)&&(e[a]=n[a])}return e},r=n(0),c=a(r),d=n(495),u=a(d);t.default=function(e){return c.default.createElement("div",{className:u.default.body},c.default.createElement("div",o({className:u.default.bodyContent,"data-ysp":"component",draggable:"true"},e)))},e.exports=t.default},495:function(e,t){e.exports={content:"X7cpbAZwpVGl9K2R8_8Dn",head:"_1MvDACj7Xui5ALEeKmaNhX",head_no:"cDzj0lD8fwvD4QScTLVug",body:"_3wjRcHZejbeBvlGmp9dA6r",bodyContent:"_3SiXYz_mDeLt1F-_QSAjIr",icon:"yfdr1ycQVcCC1hS-HeNY8"}}});