/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([61],{420:function(e,r,t){"use strict";function a(e){return e&&e.__esModule?e:{default:e}}function n(e,r){var t={};for(var a in e)r.indexOf(a)>=0||Object.prototype.hasOwnProperty.call(e,a)&&(t[a]=e[a]);return t}Object.defineProperty(r,"__esModule",{value:!0});var l=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a])}return e},c=t(0),o=a(c),u=t(12),s=a(u),f=t(77);r.default=function(e){var r=e.className,t=e.children,a=n(e,["className","children"]);return o.default.createElement(f.Grid,l({},a,{className:(0,s.default)(r,"g-collapse")}),t)},e.exports=r.default}});