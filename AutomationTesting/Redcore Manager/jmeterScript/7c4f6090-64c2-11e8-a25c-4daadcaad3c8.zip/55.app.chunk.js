/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([55],{434:function(e,t,u){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=u(0),r=(function(e){return e&&e.__esModule?e:{default:e}})(n),a=u(79);t.default=function(e){return r.default.createElement(a.TabItem,e)},e.exports=t.default}});