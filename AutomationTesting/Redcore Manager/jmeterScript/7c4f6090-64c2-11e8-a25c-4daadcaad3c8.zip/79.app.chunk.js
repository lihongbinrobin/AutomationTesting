/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([79],{389:function(e,t,r){"use strict";function n(e,t){var r={};for(var n in e)t.indexOf(n)>=0||Object.prototype.hasOwnProperty.call(e,n)&&(r[n]=e[n]);return r}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},a=r(0),i=(function(e){return e&&e.__esModule?e:{default:e}})(a);t.default=function(e){var t=(e.tabTitle,e.onClickForTitle,e.config,e.data,e.properties,n(e,["tabTitle","onClickForTitle","config","data","properties"]));return i.default.createElement("div",o({"data-ysp":"component"},t))},e.exports=t.default}});