/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([80],{393:function(e,a,t){"use strict";Object.defineProperty(a,"__esModule",{value:!0});var n=t(0),l=(function(e){return e&&e.__esModule?e:{default:e}})(n);a.default=function(e){var a=e.cols,t=e.menus,n=e.handleClick;return l.default.createElement("ul",{className:"am-menu-nav am-avg-sm-"+a},t.map((function(e,a){return l.default.createElement("li",{key:a,className:"am-parent",onClick:function(){n(e,a)}},l.default.createElement("a",null,e))})))},e.exports=a.default}});