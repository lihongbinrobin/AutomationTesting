/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
function filterCustomData(t){t.map((function(t){if(t.layout&&Array.isArray(t.layout)&&t.layout.length>0)filterCustomData(t.layout);else switch(t.type){case"custom":try{if(!t.data.customData)return;"object"==typeof t.data.customData?recursiveFilterData(t.data.customData):t.data.customData=""}catch(t){console.log(t)}break;case"textbox":case"passwordbox":console.log(t),t.data.value=""}}))}function recursiveFilterData(t){for(var a in t)Array.isArray(t[a])?t[a]=[]:"object"!=typeof t[a]?"string"!=typeof t[a]?"boolean"!=typeof t[a]?"number"!=typeof t[a]||(t[a]=""):t[a]=null:t[a]="":recursiveFilterData(t[a])}onmessage=function(t){try{var a=t.data;filterCustomData(a.page.view.slice(0)),postMessage(a)}catch(t){console.log(t.message)}};