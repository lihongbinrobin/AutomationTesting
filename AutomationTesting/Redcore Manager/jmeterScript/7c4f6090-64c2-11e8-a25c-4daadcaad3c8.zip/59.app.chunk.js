/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([59],{423:function(e,t,r){"use strict";function n(e){return e&&e.__esModule?e:{default:e}}function a(e,t){var r={};for(var n in e)t.indexOf(n)>=0||Object.prototype.hasOwnProperty.call(e,n)&&(r[n]=e[n]);return r}Object.defineProperty(t,"__esModule",{value:!0});var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},c=r(0),s=n(c),l=r(12),u=n(l);t.default=function(e){var t=e.className,r=(e.interiorCustomHandler,e.text),n=e.src,c=a(e,["className","interiorCustomHandler","text","src"]);return s.default.createElement("a",o({},c,{href:n,className:(0,u.default)("btn btn-secondary btn-block waves-effect",t)}),r)},e.exports=t.default}});