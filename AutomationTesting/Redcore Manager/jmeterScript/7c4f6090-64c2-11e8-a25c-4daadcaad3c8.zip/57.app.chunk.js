/**
 * studio - IDE for building Enterplorer apps
 * @version v2.2.1-beta.2
 * @compileTime 2018-04-11T02:07:50.128Z
 */
webpackJsonp([57],{425:function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var a=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},s=r(0),l=(function(e){return e&&e.__esModule?e:{default:e}})(s),n=l.default.createClass({displayName:"Listbox",render:function(){var e,t=this.props.items,r=this.props.selectedIndex;return!t||t&&0===t.length?(t=[],r=0):e=t[r].value,l.default.createElement("select",a({},this.props,{value:e,className:this.props.className,style:{backgroundColor:this.props.disabled||this.props.readOnly?"#f2f2f2":""}}),t.map((function(e,t){return l.default.createElement("option",{value:e.value,key:t},e.text)})))}});t.default=n,e.exports=t.default}});